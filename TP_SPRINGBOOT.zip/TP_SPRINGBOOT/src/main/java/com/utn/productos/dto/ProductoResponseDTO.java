package com.utn.productos.dto;

import com.utn.productos.model.Categoria;
import com.utn.productos.model.Producto;

/**
 * DTO de tipo record para las respuestas que incluyen información de un producto.
 * Los records son perfectos para DTOs de solo lectura: son inmutables, concisos y automáticamente
 * generan constructor, getters, equals(), hashCode() y toString().
 *
 * Incluye todos los campos incluyendo el ID.
 * No tiene validaciones ya que es de solo lectura.
 */
public record ProductoResponseDTO(
        Long id,
        String nombre,
        String descripcion,
        Double precio,
        Integer stock,
        Categoria categoria
) {
    /**
     * Convierte una entidad Producto a un DTO de respuesta.
     * Patrón Factory Method para encapsular la lógica de conversión.
     *
     * @param producto Entidad a convertir
     * @return DTO con todos los datos del producto
     */
    public static ProductoResponseDTO fromEntity(Producto producto) {
        return new ProductoResponseDTO(
                producto.getId(),
                producto.getNombre(),
                producto.getDescripcion(),
                producto.getPrecio(),
                producto.getStock(),
                producto.getCategoria()
        );
    }
}
