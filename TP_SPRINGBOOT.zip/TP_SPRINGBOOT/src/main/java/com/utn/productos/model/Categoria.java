package com.utn.productos.model;

/**
 * Enum que representa las categorías disponibles para los productos.
 * Define las clasificaciones principales del inventario.
 */
public enum Categoria {
    ELECTRONICA,
    ROPA,
    ALIMENTOS,
    HOGAR,
    DEPORTES
}
