package com.utn.productos.exception;

/**
 * Excepción personalizada lanzada cuando hay problemas relacionados con el stock.
 * Ejemplo: intentar eliminar un producto que aún tiene stock.
 *
 * NOTA: Esta es una regla de negocio adicional implementada como buena práctica,
 * aunque no estaba explícitamente requerida en la consigna del TP.
 */
public class StockInsuficienteException extends RuntimeException {

    /**
     * Constructor que acepta un mensaje descriptivo del error.
     *
     * @param mensaje Descripción del error relacionado con el stock
     */
    public StockInsuficienteException(String mensaje) {
        super(mensaje);
    }
}
