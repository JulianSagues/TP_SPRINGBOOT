package com.utn.productos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la aplicación Spring Boot.
 *
 * @SpringBootApplication es una anotación compuesta que incluye:
 * - @Configuration: Indica que esta clase define configuración de Spring
 * - @EnableAutoConfiguration: Habilita la configuración automática de Spring Boot
 * - @ComponentScan: Escanea el paquete actual y sus subpaquetes en busca de componentes
 *
 * Esta aplicación expone una API REST completa para gestión de productos.
 */
@SpringBootApplication
public class ProductosApiApplication {

    /**
     * Punto de entrada de la aplicación.
     * Inicia el servidor embebido y el contexto de Spring.
     *
     * @param args Argumentos de línea de comandos
     */
    public static void main(String[] args) {
        SpringApplication.run(ProductosApiApplication.class, args);
    }
}
