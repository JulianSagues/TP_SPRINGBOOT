package com.utn.productos.exception;

/**
 * Excepción personalizada lanzada cuando no se encuentra un producto.
 * Extiende RuntimeException para ser una excepción no verificada.
 */
public class ProductoNotFoundException extends RuntimeException {

    /**
     * Constructor que acepta un mensaje descriptivo del error.
     *
     * @param mensaje Descripción del error
     */
    public ProductoNotFoundException(String mensaje) {
        super(mensaje);
    }

    /**
     * Constructor de conveniencia que genera un mensaje estándar con el ID.
     *
     * @param id Identificador del producto no encontrado
     */
    public ProductoNotFoundException(Long id) {
        super("No se encontró el producto con ID: " + id);
    }
}
